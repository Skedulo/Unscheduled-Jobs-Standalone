export const constants = {
    API_GET_AVAILABLE_RESOURCE: 'https://api.au.skedulo.com/availability/resources',
    API_GET_GRID_SCHEDULE: 'https://api.au.skedulo.com/planr/grid/schedule',
};